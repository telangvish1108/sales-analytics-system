
def calculate_total_revenue(transactions):
    total = 0.0
    for tx in transactions:
        total += tx['Quantity'] * tx['UnitPrice']
    return round(total, 2)


def region_wise_sales(transactions):
    region_data = {}
    total_revenue = calculate_total_revenue(transactions)

    for tx in transactions:
        region = tx['Region']
        amount = tx['Quantity'] * tx['UnitPrice']

        if region not in region_data:
            region_data[region] = {
                'total_sales': 0.0,
                'transaction_count': 0
            }

        region_data[region]['total_sales'] += amount
        region_data[region]['transaction_count'] += 1

    result = {}
    for region, data in region_data.items():
        percentage = (data['total_sales'] / total_revenue) * 100 if total_revenue else 0
        result[region] = {
            'total_sales': round(data['total_sales'], 2),
            'transaction_count': data['transaction_count'],
            'percentage': round(percentage, 2)
        }

    return dict(sorted(result.items(),
                       key=lambda x: x[1]['total_sales'],
                       reverse=True))


def customer_analysis(transactions):
    customer_stats = {}

    for tx in transactions:
        cid = tx['CustomerID']
        amount = tx['Quantity'] * tx['UnitPrice']
        product = tx['ProductName']

        if cid not in customer_stats:
            customer_stats[cid] = {
                'total_spent': 0.0,
                'purchase_count': 0,
                'products': set()
            }

        customer_stats[cid]['total_spent'] += amount
        customer_stats[cid]['purchase_count'] += 1
        customer_stats[cid]['products'].add(product)

    result = {}
    for cid, data in customer_stats.items():
        result[cid] = {
            'total_spent': round(data['total_spent'], 2),
            'purchase_count': data['purchase_count'],
            'avg_order_value': round(
                data['total_spent'] / data['purchase_count'], 2
            ),
            'products_bought': sorted(list(data['products']))
        }

    return dict(sorted(result.items(),
                       key=lambda x: x[1]['total_spent'],
                       reverse=True))

def top_selling_products(transactions, n=5):
    product_summary = {}

    for tx in transactions:
        product = tx['ProductName']
        qty = tx['Quantity']
        revenue = tx['Quantity'] * tx['UnitPrice']

        if product not in product_summary:
            product_summary[product] = {
                'total_quantity': 0,
                'total_revenue': 0.0
            }

        product_summary[product]['total_quantity'] += qty
        product_summary[product]['total_revenue'] += revenue

    result = []
    for product, data in product_summary.items():
        result.append(
            (product,
             data['total_quantity'],
             round(data['total_revenue'], 2))
        )

    result.sort(key=lambda x: x[1], reverse=True)
    return result[:n]
